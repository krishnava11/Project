import tkinter as tk
import cv2
from tkinter.filedialog import askopenfilename
import shutil
import os
import sys
from PIL import Image, ImageTk
import numpy as np

window = tk.Tk()

window.title("Dr. Plant")

window.geometry("500x510")
window.configure(background ="lightgreen")

title = tk.Label(text="Click below to choose picture for testing disease....", background = "lightgreen", fg="Brown", font=("", 15))
title.grid()
	

def openphoto():
    dirPath = "test"
    fileList = os.listdir(dirPath)
    verifying_data = []
    verify_dir = 'test'
    IMG_SIZE = 50
    LR = 1e-3
    cwd=os.getcwd();cwd=cwd+'\test'
    for fileName in fileList:
        os.remove(dirPath + "/" + fileName)
    # C:/Users/sagpa/Downloads/images is the location of the image which you want to test..... you can change it according to the image location you have  
    fileName = askopenfilename(initialdir=cwd, title='Select image for analysis ',
                           filetypes=[('image files', '.jpg')])
    #dst = "D:\\Users\\KrishnVa\\Desktop\\Python MS Pr\\PlantDiseaseDetection-master\\testpicture"
    #shutil.copy(fileName, dst)
    load = Image.open(fileName)
    render = ImageTk.PhotoImage(load)
    img = tk.Label(image=render, height="250", width="500")
    img.image = render
    img.place(x=0, y=0)
    img.grid(column=0, row=1, padx=10, pady = 10)
    img_num = fileName.split('.')[0];
    img=cv2.imread(fileName,cv2.IMREAD_COLOR);
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    verifying_data.append([np.array(img), img_num])
    np.save('verify_data.npy', verifying_data)
    #path = os.path.join(dst, img)
    title.destroy()
    button1.destroy()
    button = tk.Button(text="Exit", command=exit)
    button.grid(column=0, row=9, padx=20, pady=20)
    #button2 = tk.Button(text="Analyse Image", command=analysis)
    #button2.grid(column=0, row=2, padx=10, pady = 10)

button1 = tk.Button(text="Get Photo", command = openphoto)
button1.grid(column=0, row=1, padx=10, pady = 10)
window.mainloop()